Example outputs that should be close-ish. Note they may note be exact because of randomness.

parameters used:
- raw raw_weight.out raw_returns.out 20 200 0.05 0.99 0.01
- tile tile_weight.out tile_returns.out 20 200 0.05 0.99 0.00005